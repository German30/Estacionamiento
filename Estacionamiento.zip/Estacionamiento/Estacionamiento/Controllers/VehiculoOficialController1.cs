﻿using Estacionamiento.Models;
using Estacionamiento.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Estacionamiento.Controllers
{
    public class VehiculoOficialController1 : Controller
    {
        private IVehiculoOficial db = new VehiculoOficialCollection();

        // GET: VehiculoOficialController1
        public ActionResult Index()
        {
            var vehiculoOficial = db.GetAllVehiculoOficial();
            return View(vehiculoOficial);
        }

        // GET: VehiculoOficialController1/Details/5
        public ActionResult Details(string id)
        {
            var vehiculoOficial = db.GetVehiculoOficial(id);
            return View();
        }

        // GET: VehiculoOficialController1/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: VehiculoOficialController1/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var vehiculoOficial = new VehiculoOficial()
                {
                    Placa = collection["Placa"]
                };
                db.InsertarVehiculoOficial(vehiculoOficial);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VehiculoOficialController1/Edit/5
        public ActionResult Edit(string id)
        {
            var vehiculoOficial = db.GetVehiculoOficial(id);
            return View();
        }

        // POST: VehiculoOficialController1/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id, IFormCollection collection)
        {
            try
            {
                var vehiculoOficial = new VehiculoOficial()
                {
                    Placa = collection["Placa"]
                };
                db.UpdateVehiculoOficial(vehiculoOficial);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VehiculoOficialController1/Delete/5
        public ActionResult Delete(string id)
        {
            var vehiculoOficial = db.GetVehiculoOficial(id);
            return View();
        }

        // POST: VehiculoOficialController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, IFormCollection collection)
        {
            try
            {
                db.DeleteVehiculoOficial(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
