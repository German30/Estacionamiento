﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using Estacionamiento.Models;
using Estacionamiento.Repository;

namespace Estacionamiento.Controllers
{
    public class RegEntradaController1 : Controller
    {
        private IRegEntradaCollection db = new RegEntradaCollection();

        // GET: RegEntradaController1
        public ActionResult Index()
        {
            var regEntrada = db.GetAll();
            return View(regEntrada);
        }

        // GET: RegEntradaController1/Details/5
        public ActionResult Details(string id)
        {
            var regEntrada = db.GetRegEntrada(id);
            return View(regEntrada);
        }

        // GET: RegEntradaController1/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: RegEntradaController1/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var regEntrada = new RegEntrada()
                {
                    Placa = collection["Placa"],
                    Entrada = Double.Parse(collection["Entrada"]),
                    Salida = Double.Parse(collection["Salida"]),
                    Total = Double.Parse(collection["Entrada"]) - Double.Parse(collection["Salida"]) * 0.05
                };
                db.InsertRegEntrada(regEntrada);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: RegEntradaController1/Edit/5
        public ActionResult Edit(string id)
        {
            var regEntrad = db.GetRegEntrada(id);
            return View(regEntrad);
        }

        // POST: RegEntradaController1/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id, IFormCollection collection)
        {
            try
            {
                var regEntrada = new RegEntrada()
                {
                    Id = new ObjectId(id),
                    Placa = collection["Placa"],
                    Entrada = Double.Parse(collection["Entrada"]),
                    Salida = Double.Parse(collection["Salida"]),
                    Total = Double.Parse(collection["Entrada"]) - Double.Parse(collection["Salida"]) * 0.05
                };
                db.UpdateRegEntrada(regEntrada);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: RegEntradaController1/Delete/5
        public ActionResult Delete(string id)
        {
            var regEntrada = db.GetRegEntrada(id);
            return View(regEntrada);
        }

        // POST: RegEntradaController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, IFormCollection collection)
        {
            try
            {
                db.DeleteRegEntrada(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
