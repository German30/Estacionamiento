﻿using Estacionamiento.Repository.Residente;
using Estacionamiento.Models.Residente;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Estacionamiento.Repository;

namespace Estacionamiento.Controllers
{
    public class VehiculoResidenteController1 : Controller
    {
        private IVehiculoResidente db = new VehiculoResidenteCollection();

        // GET: VehiculoResidenteController1
        public ActionResult Index()
        {
            var vehiculoResidente = db.GetAllVehiculoResidente();
            return View(vehiculoResidente);
        }

        // GET: VehiculoResidenteController1/Details/5
        public ActionResult Details(string id)
        {
            var vehiculoResidente = db.GetVehiculoResidente(id);
            return View(vehiculoResidente);
        }

        // GET: VehiculoResidenteController1/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: VehiculoResidenteController1/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var vehiculoResidente = new VehiculoResidente()
                {
                    Placa = collection["Placa"]
                };
                db.InsertarVehiculoResidente(vehiculoResidente);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VehiculoResidenteController1/Edit/5
        public ActionResult Edit(string id)
        {
            var vehiculoResidente = db.GetVehiculoResidente(id);
            return View();
        }

        // POST: VehiculoResidenteController1/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id, IFormCollection collection)
        {
            try
            {
                var vehiculoResidente = new VehiculoResidente()
                {
                    Placa = collection["Placa"]
                };
                db.UpdateVehiculoResidente(vehiculoResidente);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VehiculoResidenteController1/Delete/5
        public ActionResult Delete(string id)
        {
            var vehiculoResidente = db.GetVehiculoResidente(id);
            return View();
        }

        // POST: VehiculoResidenteController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, IFormCollection collection)
        {
            try
            {
                db.DeleteVehiculoResidente(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
