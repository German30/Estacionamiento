﻿using Estacionamiento.Models;

namespace Estacionamiento.Repository
{
    public interface IRegEntradaCollection
    {
        void InsertRegEntrada(RegEntrada regEntrada);

        void UpdateRegEntrada(RegEntrada regEntrada);

        void DeleteRegEntrada(string id);

        List<RegEntrada> GetAll();

        RegEntrada GetRegEntrada(String id);

        Object GetRegEntradaById(String id);
    }
}
