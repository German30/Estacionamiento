﻿using Estacionamiento.Models;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Estacionamiento.Repository
{
    public class VehiculoOficialCollection : IVehiculoOficial
    {
        internal MongoDBRepository repository = new MongoDBRepository();
        private IMongoCollection<VehiculoOficial> collection;
        
        public VehiculoOficialCollection()
        {
            collection = repository.db.GetCollection<VehiculoOficial>("VehiculoOficial");
        }
        
        public void DeleteVehiculoOficial(string id)
        {
            var filter = Builders<VehiculoOficial>.Filter.Eq(s => s.Id, new ObjectId(id));
            collection.DeleteOneAsync(filter);
        }

        public List<VehiculoOficial> GetAllVehiculoOficial()
        {
            var query = collection.Find(new BsonDocument()).ToListAsync();
            return query.Result;
        }

        public VehiculoOficial GetVehiculoOficial(string id)
        {
            var vehiculoOficial = collection.Find(new BsonDocument { { "_id", new ObjectId(id) } }).FirstAsync().Result;
            return vehiculoOficial;
        }

        public object GetVehiculoOficialById(string id)
        {
            var vehiculoOficial = collection.Find(new BsonDocument { { "_id", new ObjectId(id) } }).FirstAsync().Result;
            return vehiculoOficial;
        }

        public void InsertarVehiculoOficial(VehiculoOficial vehiculoOficial)
        {
            collection.InsertOneAsync(vehiculoOficial);
        }

        public void UpdateVehiculoOficial(VehiculoOficial vehiculoOficial)
        {
            var filter = Builders<VehiculoOficial>.Filter.Eq(s => s.Id, vehiculoOficial.Id);
            collection.ReplaceOneAsync(filter, vehiculoOficial);
        }
    }
}
