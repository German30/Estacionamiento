﻿using MongoDB.Bson;
using MongoDB.Driver;
using Estacionamiento.Models;

namespace Estacionamiento.Repository
{
    public class RegEntradaCollection : IRegEntradaCollection
    {   
        internal MongoDBRepository repository = new MongoDBRepository();
        private IMongoCollection<RegEntrada> Collection;

        public RegEntradaCollection() 
        {
            Collection = repository.db.GetCollection<RegEntrada>("RegEntrada");
        }

        public void DeleteRegEntrada(string id)
        {
           var filter = Builders<RegEntrada>.Filter.Eq(s => s.Id, new ObjectId(id));
            Collection.DeleteOneAsync(filter);
        }

        public List<RegEntrada> GetAll()
        {
            var query = Collection.Find(new BsonDocument()).ToListAsync();
            return query.Result;
        }

        public RegEntrada GetRegEntrada(string id)
        {
            var regEntrada = Collection.Find(new BsonDocument { { "_id", new ObjectId(id) } }).FirstAsync().Result;
            return regEntrada;
        }

        public object GetRegEntradaById(string id)
        {
            var regEntrada = Collection.Find(new BsonDocument { { "_id", new ObjectId(id) } }).FirstAsync().Result;
            return regEntrada;
        }

        public void InsertRegEntrada(RegEntrada regEntrada)
        {
            Collection.InsertOneAsync(regEntrada);
        }

        public void UpdateRegEntrada(RegEntrada regEntrada)
        {
            var filter = Builders<RegEntrada>.Filter.Eq(s => s.Id, regEntrada.Id);
            Collection.ReplaceOneAsync(filter, regEntrada);
        }
    }
}
