﻿using Estacionamiento.Models;

namespace Estacionamiento.Repository
{
    public interface IVehiculoOficial
    {
        void InsertarVehiculoOficial(VehiculoOficial vehiculoOficial);

        void UpdateVehiculoOficial(VehiculoOficial vehiculoOficial);

        void DeleteVehiculoOficial(string id);

        List<VehiculoOficial> GetAllVehiculoOficial();

        VehiculoOficial GetVehiculoOficial(String id);

        Object GetVehiculoOficialById(String id);
    }
}
