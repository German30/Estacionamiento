﻿using Estacionamiento.Models;
using Estacionamiento.Models.Residente;

namespace Estacionamiento.Repository.Residente
{
    public interface IVehiculoResidente 
    { 
        void InsertarVehiculoResidente(VehiculoResidente vehiculoResidente);

        void UpdateVehiculoResidente(VehiculoResidente vehiculoResidente);

        void DeleteVehiculoResidente(string id);

        List<VehiculoResidente> GetAllVehiculoResidente();

        VehiculoResidente GetVehiculoResidente(String id);

        Object GetVehiculoResidenteById(String id);
    }
}
