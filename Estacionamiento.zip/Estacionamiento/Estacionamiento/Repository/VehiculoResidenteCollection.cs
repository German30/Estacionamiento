﻿using MongoDB.Driver;
using MongoDB.Bson;
using Estacionamiento.Models.Residente;
using Estacionamiento.Repository.Residente;

namespace Estacionamiento.Repository
{
    public class VehiculoResidenteCollection : IVehiculoResidente
    {
        internal MongoDBRepository repository = new MongoDBRepository();
        private IMongoCollection<VehiculoResidente> collection;

        public VehiculoResidenteCollection()
        {
            collection = repository.db.GetCollection<VehiculoResidente>("VehiculoResidente");
        }

        public void DeleteVehiculoResidente(string id)
        {
            var filter = Builders<VehiculoResidente>.Filter.Eq(s => s.Id, new ObjectId(id));
            collection.DeleteOneAsync(filter);
        }

        public List<VehiculoResidente> GetAllVehiculoResidente()
        {
            var query = collection.Find(new BsonDocument()).ToListAsync();
            return query.Result;
        }

        public VehiculoResidente GetVehiculoResidente(string id)
        {
            var vehiculoResidente = collection.Find(new BsonDocument { { "_id", new ObjectId(id) } }).FirstAsync().Result;
            return vehiculoResidente;
        }

        public object GetVehiculoResidenteById(string id)
        {
            var vehiculoResidente = collection.Find(new BsonDocument { { "_id", new ObjectId(id) } }).FirstAsync().Result;
            return vehiculoResidente;
        }

        public void InsertarVehiculoResidente(VehiculoResidente vehiculoResidente)
        {
            collection.InsertOneAsync(vehiculoResidente);
        }

        public void UpdateVehiculoResidente(VehiculoResidente vehiculoResidente)
        {
            var filter = Builders<VehiculoResidente>.Filter.Eq(s => s.Id, vehiculoResidente.Id);
            collection.ReplaceOneAsync(filter, vehiculoResidente);
        }
    }
}
