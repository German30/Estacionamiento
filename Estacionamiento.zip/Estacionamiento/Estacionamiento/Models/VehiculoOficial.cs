﻿using MongoDB.Driver;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Estacionamiento.Models
{
    public class VehiculoOficial
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public string Placa { get; set; }
    }
}
