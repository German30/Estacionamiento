﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Estacionamiento.Models.Residente
{
    public class VehiculoResidente
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public string Placa { get; set; }
    }
}
