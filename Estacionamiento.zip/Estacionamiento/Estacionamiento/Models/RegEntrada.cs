﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Estacionamiento.Models
{
    public class RegEntrada
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public string Placa { get; set; }
        
        public double Entrada { get; set; }

        public double Salida { get; set; }

        public double Total { get; set; }

    }
}
